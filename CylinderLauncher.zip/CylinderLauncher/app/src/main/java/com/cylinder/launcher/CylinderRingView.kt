package com.cylinder.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/** The glowing blue/violet rings under the cylinder. */
class CylinderRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val oval = RectF()

    // (radius factor, stroke width dp, start colour, end colour)
    private data class Ring(val scale: Float, val strokeDp: Float, val c1: Int, val c2: Int)

    private val rings = listOf(
        Ring(1.00f, 1.6f, 0xFF7FD6F7.toInt(), 0xFF4EA3F5.toInt()),
        Ring(0.93f, 2.2f, 0xFF5B7CFA.toInt(), 0xFF9B6BFF.toInt()),
        Ring(0.80f, 1.0f, 0x66A6C8FF, 0x66C4B0FF)
    )

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val rx = w * 0.46f
        val ry = rx * 0.17f

        // Soft glow disc on the "floor".
        glow.shader = RadialGradient(
            cx, cy, rx,
            intArrayOf(0x33A6C8FF, 0x00A6C8FF),
            floatArrayOf(0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.scale(1f, ry / rx, cx, cy)
        canvas.drawCircle(cx, cy, rx, glow)
        canvas.restore()

        for (r in rings) {
            ring.strokeWidth = r.strokeDp * density
            ring.shader = LinearGradient(cx - rx, cy, cx + rx, cy, r.c1, r.c2, Shader.TileMode.CLAMP)
            val rrx = rx * r.scale
            val rry = ry * r.scale
            oval.set(cx - rrx, cy - rry, cx + rrx, cy + rry)
            canvas.drawOval(oval, ring)
        }
    }
}
