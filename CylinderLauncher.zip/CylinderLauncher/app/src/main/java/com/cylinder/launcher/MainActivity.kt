package com.cylinder.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.os.UserManager
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var launcherApps: LauncherApps
    private lateinit var userManager: UserManager
    private lateinit var pager: ViewPager2
    private lateinit var indicator: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = reloadApps()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = reloadApps()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = reloadApps()
        override fun onPackagesAvailable(
            packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
        ) = reloadApps()

        override fun onPackagesUnavailable(
            packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
        ) = reloadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        setContentView(R.layout.activity_main)

        launcherApps = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        userManager = getSystemService(Context.USER_SERVICE) as UserManager

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        pager = findViewById(R.id.view_pager)
        indicator = findViewById(R.id.indicator)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.drawer_list)

        pager.offscreenPageLimit = 1
        pager.setPageTransformer(CylinderTransformer())
        // Let neighbouring pages be drawn outside the pager's padding so the cylinder is visible.
        (pager.getChildAt(0) as RecyclerView).apply {
            clipToPadding = false
            clipChildren = false
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = highlightDot(position)
        })

        drawerList.layoutManager = GridLayoutManager(this, HomePagerAdapter.COLUMNS)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawer.visibility == View.VISIBLE) hideDrawer()
            }
        })

        reloadApps()
    }

    override fun onStart() {
        super.onStart()
        launcherApps.registerCallback(appsCallback, main)
    }

    override fun onStop() {
        launcherApps.unregisterCallback(appsCallback)
        super.onStop()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    /** Home button pressed while we are already on top: go back to the first page. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) {
            hideDrawer()
            pager.setCurrentItem(0, true)
        }
    }

    // ---------------------------------------------------------------- apps

    private fun reloadApps() {
        io.execute {
            val apps = userManager.userProfiles
                .flatMap { user ->
                    launcherApps.getActivityList(null, user).map {
                        AppItem(it.label.toString(), it.componentName, user, it.getBadgedIcon(0))
                    }
                }
                .filter { it.component.packageName != packageName }
                .sortedBy { it.label.lowercase() }
            val dockEntries = resolveDock()
            main.post { if (!isDestroyed) render(apps, dockEntries) }
        }
    }

    private fun render(apps: List<AppItem>, dockEntries: List<DockEntry>) {
        val pages = apps.chunked(HomePagerAdapter.APPS_PER_PAGE)
        val current = pager.currentItem
        pager.adapter = HomePagerAdapter(pages, ::launch, ::openAppInfo)
        if (current < pages.size) pager.setCurrentItem(current, false)

        buildIndicator(pages.size)
        highlightDot(pager.currentItem)
        buildDock(dockEntries)

        drawerList.adapter = AppGridAdapter(
            apps,
            onClick = { hideDrawer(); launch(it) },
            onLongClick = ::openAppInfo
        )
    }

    private fun launch(app: AppItem) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    private fun openAppInfo(app: AppItem) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- dock

    private class DockEntry(val intent: Intent, val icon: Drawable)

    private fun resolveDock(): List<DockEntry> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
        )
        return intents.mapNotNull { intent ->
            val info = pm.queryIntentActivities(intent, 0).firstOrNull() ?: return@mapNotNull null
            intent.setClassName(info.activityInfo.packageName, info.activityInfo.name)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            DockEntry(intent, info.loadIcon(pm))
        }
    }

    private fun buildDock(entries: List<DockEntry>) {
        dock.removeAllViews()
        val size = dp(52)
        val margin = dp(7)

        fun slot(icon: Drawable, onClick: () -> Unit) = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                setMargins(margin, 0, margin, 0)
            }
            setImageDrawable(icon)
            setOnClickListener { onClick() }
        }

        val drawerButton = ContextCompat.getDrawable(this, R.drawable.ic_apps)!!
        val middle = entries.size / 2
        entries.forEachIndexed { i, e ->
            if (i == middle) dock.addView(slot(drawerButton) { showDrawer() }.also {
                it.setBackgroundResource(R.drawable.bg_drawer_btn)
                it.setPadding(dp(13), dp(13), dp(13), dp(13))
            })
            dock.addView(slot(e.icon) {
                try { startActivity(e.intent) } catch (_: Exception) {}
            })
        }
        if (entries.isEmpty()) {
            dock.addView(slot(drawerButton) { showDrawer() })
        }
    }

    // ------------------------------------------------------------ drawer

    private fun showDrawer() {
        drawer.alpha = 0f
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).setDuration(180).start()
    }

    private fun hideDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        drawer.animate().alpha(0f).setDuration(150).withEndAction {
            drawer.visibility = View.GONE
        }.start()
    }

    // --------------------------------------------------------- indicator

    private fun buildIndicator(count: Int) {
        indicator.removeAllViews()
        if (count <= 1) return
        repeat(count) {
            indicator.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(6), dp(6)).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                }
                setBackgroundResource(R.drawable.dot)
            })
        }
    }

    private fun highlightDot(selected: Int) {
        for (i in 0 until indicator.childCount) {
            indicator.getChildAt(i).alpha = if (i == selected) 1f else 0.35f
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
