package com.cylinder.launcher

import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** One ViewPager2 page = one 4-column grid of apps. */
class HomePagerAdapter(
    private val pages: List<List<AppItem>>,
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<HomePagerAdapter.PageVH>() {

    class PageVH(val list: RecyclerView) : RecyclerView.ViewHolder(list)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val ctx = parent.context
        val density = ctx.resources.displayMetrics.density
        val list = RecyclerView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            layoutManager = GridLayoutManager(ctx, COLUMNS)
            // Leave room for the clock header above and the dock/indicator below.
            setPadding(0, (HEADER_SPACE_DP * density).toInt(), 0, 0)
            clipToPadding = false
            overScrollMode = View_OVER_SCROLL_NEVER
        }
        return PageVH(list)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.list.adapter = AppGridAdapter(pages[position], onClick, onLongClick)
    }

    override fun getItemCount() = pages.size

    companion object {
        const val COLUMNS = 4
        const val ROWS = 4
        const val APPS_PER_PAGE = COLUMNS * ROWS
        private const val HEADER_SPACE_DP = 170
        private const val View_OVER_SCROLL_NEVER = android.view.View.OVER_SCROLL_NEVER
    }
}
