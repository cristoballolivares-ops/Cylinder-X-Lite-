package com.cylinder.launcher

import android.view.View
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/**
 * Wraps the pages around a vertical axis so the home screen looks like a
 * glass cylinder. Tweak MAX_ANGLE / PULL_IN / MIN_SCALE / MIN_ALPHA to taste.
 */
class CylinderTransformer : ViewPager2.PageTransformer {

    override fun transformPage(page: View, position: Float) {
        val p = position.coerceIn(-1f, 1f)
        val density = page.resources.displayMetrics.density

        page.cameraDistance = 12000f * density
        page.pivotX = page.width / 2f
        page.pivotY = page.height / 2f

        page.rotationY = -MAX_ANGLE * p                 // turn away from the viewer
        page.translationX = -p * page.width * PULL_IN   // tuck toward the centre
        val scale = 1f - (1f - MIN_SCALE) * abs(p)
        page.scaleX = scale
        page.scaleY = scale
        page.alpha = 1f - (1f - MIN_ALPHA) * abs(p)
    }

    private companion object {
        const val MAX_ANGLE = 40f
        const val PULL_IN = 0.16f
        const val MIN_SCALE = 0.92f
        const val MIN_ALPHA = 0.55f
    }
}
